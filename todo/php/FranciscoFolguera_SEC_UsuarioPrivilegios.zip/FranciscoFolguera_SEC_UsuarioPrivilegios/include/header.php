<!DOCTYPE html>
<html lang="ES">
	<head>
		<title>Usuarios con privilegios</title>			 
		<meta name="author" content="Francisco Folguera ">
		<meta charset="UTF-8">
	</head>
	<body>
	
	