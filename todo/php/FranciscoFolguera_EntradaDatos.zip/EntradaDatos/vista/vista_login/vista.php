
<?php 

$titulo='Listado de presentadores 3.0';
$contenido=  './vista/vista_login/miPlantilla.php';
//include 'vista/miLayoutCss.php';
include './vista/vista_login/miLayout.php';