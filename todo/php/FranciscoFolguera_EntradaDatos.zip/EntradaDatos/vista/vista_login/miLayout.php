
<!DOCTYPE html>
<html lang="ES">
    <head>
        <title><?php echo $titulo ?></title>	
        <meta name="author" content="Francisco Folguera ">
        <meta charset="UTF-8">
    </head>
    <body>

    <?php include  $contenido ?>


    </body>
</html>