<!DOCTYPE html>
<html lang="ES">
	<head>
		<title>CRUD de alumnos y asignaturas</title>			 
		<meta name="author" content="Francisco Folguera ">
		<meta charset="UTF-8">
                <link href="../include/css.css" rel="stylesheet" type="text/css"/>
	</head>
	<body>
	
	