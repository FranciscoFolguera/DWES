
<?php

$titulo = 'EJERCICIO 3';
$contenido = './vista/vista_login/miPlantilla.php';
//include 'vista/miLayoutCss.php';
include './vista/vista_login/miLayout.php';
