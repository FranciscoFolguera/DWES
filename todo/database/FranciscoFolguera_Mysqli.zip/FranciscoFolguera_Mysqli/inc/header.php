<!DOCTYPE html>
<html lang="ES">
	<head>
		<title>Actividades 2 PHP</title>
		 <link rel="stylesheet" type="text/css" href="../css/actividad1Css.css">
		 
		 <meta name="author" content="Francisco Folguera ">
		 <meta charset="UTF-8">
	</head>
	<body>
	
	